filename: !readme.txt
author: andrew flagg
company: mountain computers inc
release date: september 28, 2024
purpose: might as well release this for others to enjoy
copyright: andrew flagg
terms: you might use it if you let me know you want to use it. good for learning purposes.
contact info: developersupport@mountaincomputers.org



